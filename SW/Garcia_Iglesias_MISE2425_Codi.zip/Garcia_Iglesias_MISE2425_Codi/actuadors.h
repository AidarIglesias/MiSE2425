/*
 * actuadors.h
 *
 * Microcontroladors i Sistemes Empotrats
 * Curs 2024-25
 * Universitat de Barcelona
 *
 * Autors: David Garcia, Aidar Iglesias
 */

#ifndef ACTUADORS_H_
#define ACTUADORS_H_

void stop(void);
void move_forward(uint8_t fvel);
void move_backward(uint8_t bvel);
void fleft(uint8_t fleft_vel);
void bleft(uint8_t bleft_vel);
void left_rot(uint8_t lrot_vel);
void fright(uint8_t fright_vel);
void bright(uint8_t bright_vel);
void right_rot(uint8_t rrot_vel);

#endif /* ACTUADORS_H_ */
