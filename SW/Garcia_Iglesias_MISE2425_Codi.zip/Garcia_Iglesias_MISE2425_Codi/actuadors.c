/*
 * actuadors.c
 *
 * Microcontroladors i Sistemes Empotrats
 * Curs 2024-25
 * Universitat de Barcelona
 *
 * Autors: David Garcia, Aidar Iglesias
 */

/***************************** MACROS I LLIBRERIES **********************************/
#include <msp430fr2355.h>
#include <stdint.h>
#include "i2c_master.h"
/************************************************************************************/


/***************************** Variables de control *********************************/
#define LOC_ID_ROBOT 0x10       // Identificador local del robot (a nivell de llibreria)
#define LOC_ACTUATOR_ADDR 0x00  // Adreça local dels actuadors (a nivell de llibreria)
#define FDIR 1                  // Direcció de moviment posterior
#define BDIR 2                  // Direcció de moviment anterior
#define STOP_WHEEL 0            // Variable que defineix l'estat de rodes aturades
uint8_t actuator_buf[5];        // Búffer que emmagatzema l'estat dels actuadors
uint8_t actuator_blen = sizeof(actuator_buf);  // Longitud del búffer d'estat dels actuadors
/************************************************************************************/


/************************* Funcions per al moviment del robot ***********************/
// Funció per a aturar el robot
void stop(void){
    actuator_buf[0] = LOC_ACTUATOR_ADDR;
    actuator_buf[1] = FDIR;
    actuator_buf[2] = STOP_WHEEL;
    actuator_buf[3] = FDIR;
    actuator_buf[4] = STOP_WHEEL;
    I2C_send(LOC_ID_ROBOT, actuator_buf, actuator_blen);
}

// Funció per a moure endavant el robot
void move_forward(uint8_t fvel){
    actuator_buf[0] = LOC_ACTUATOR_ADDR;
    actuator_buf[1] = FDIR;
    actuator_buf[2] = fvel;
    actuator_buf[3] = FDIR;
    actuator_buf[4] = fvel;
    I2C_send(LOC_ID_ROBOT, actuator_buf, actuator_blen);
}

// Funció per a moure enrere el robot
void move_backward(uint8_t bvel){
    actuator_buf[0] = LOC_ACTUATOR_ADDR;
    actuator_buf[1] = BDIR;
    actuator_buf[2] = bvel;
    actuator_buf[3] = BDIR;
    actuator_buf[4] = bvel;
    I2C_send(LOC_ID_ROBOT, actuator_buf, actuator_blen);
}

// Funció per a girar cap a l'esquerra endavant
void fleft(uint8_t fleft_vel){
    actuator_buf[0] = LOC_ACTUATOR_ADDR;
    actuator_buf[1] = FDIR;
    actuator_buf[2] = STOP_WHEEL;
    actuator_buf[3] = FDIR;
    actuator_buf[4] = fleft_vel;
    I2C_send(LOC_ID_ROBOT, actuator_buf, actuator_blen);
}

// Funció per a girar cap a l'esquerra enrere
void bleft(uint8_t bleft_vel){
    actuator_buf[0] = LOC_ACTUATOR_ADDR;
    actuator_buf[1] = FDIR;
    actuator_buf[2] = STOP_WHEEL;
    actuator_buf[3] = BDIR;
    actuator_buf[4] = bleft_vel;
    I2C_send(LOC_ID_ROBOT, actuator_buf, actuator_blen);
}

// Funció per a rotar en sentit antihorari
void left_rot(uint8_t lrot_vel){
    actuator_buf[0] = LOC_ACTUATOR_ADDR;
    actuator_buf[1] = BDIR;
    actuator_buf[2] = lrot_vel;
    actuator_buf[3] = FDIR;
    actuator_buf[4] = lrot_vel;
    I2C_send(LOC_ID_ROBOT, actuator_buf, actuator_blen);
}

// Funció per a girar cap a la dreta endavant
void fright(uint8_t fright_vel){
    actuator_buf[0] = LOC_ACTUATOR_ADDR;
    actuator_buf[1] = FDIR;
    actuator_buf[2] = fright_vel;
    actuator_buf[3] = FDIR;
    actuator_buf[4] = STOP_WHEEL;
    I2C_send(LOC_ID_ROBOT, actuator_buf, actuator_blen);
}

// Funció per a girar cap a la dreta enrere
void bright(uint8_t bright_vel){
    actuator_buf[0] = LOC_ACTUATOR_ADDR;
    actuator_buf[1] = BDIR;
    actuator_buf[2] = bright_vel;
    actuator_buf[3] = FDIR;
    actuator_buf[4] = STOP_WHEEL;
    I2C_send(LOC_ID_ROBOT, actuator_buf, actuator_blen);
}

// Funció per a rotar en sentit horari
void right_rot(uint8_t rrot_vel){
    actuator_buf[0] = LOC_ACTUATOR_ADDR;
    actuator_buf[1] = FDIR;
    actuator_buf[2] = rrot_vel;
    actuator_buf[3] = BDIR;
    actuator_buf[4] = rrot_vel;
    I2C_send(LOC_ID_ROBOT, actuator_buf, actuator_blen);
}
/************************************************************************************/


