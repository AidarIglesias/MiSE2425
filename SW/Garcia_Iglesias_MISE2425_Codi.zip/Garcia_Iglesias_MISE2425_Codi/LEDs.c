/*
 * LEDs.c
 *
 * Microcontroladors i Sistemes Empotrats
 * Curs 2024-25
 * Universitat de Barcelona
 *
 * Autors: David Garcia, Aidar Iglesias
 */


/********************************* LLIBRERIES ***************************************/
#include <msp430fr2355.h>
#include <stdint.h>
#include "timers.h"
#include "delay_ms.h"
#include "i2c_master.h"
/************************************************************************************/


/**************************** Variables de control **********************************/
// LEDs RGB robot
// colors: 1-->RED, 2-->GREEN, 3-->YELLOW, 4-->BLUE, 5-->MAGENTA, 6-->CYAN, 7-->WHITE
#define OFF 0
#define RED 1
#define GREEN 2
#define YELLOW 3
#define BLUE 4
#define MAGENTA 5
#define CYAN 6
#define WHITE 7
// Paràmetres I2C dels LEDs
#define LOC_ID_ROBOT 0x10   // Adreça del robot
#define LED_addr 0x0B       // Adreça del controlador dels LEDs RGB del robot
#define LED_BLEN 3          // Longitud del buffer de dades dels LEDs
// Trames per a cada funció (el funcionament no es limita a les presentades)
uint8_t LEDs_OFF_buffer[3] = {LED_addr, OFF, OFF};
uint8_t RED_LEDs_buffer[3] = {LED_addr, RED, RED};
uint8_t GREEN_LEDs_buffer[3] = {LED_addr, GREEN, GREEN};
uint8_t YELLOW_LEDs_buffer[3] = {LED_addr, YELLOW, YELLOW};
uint8_t BLUE_LEDs_buffer[3] = {LED_addr, BLUE, BLUE};
uint8_t MAGENTA_LEDs_buffer[3] = {LED_addr, MAGENTA, MAGENTA};
uint8_t CYAN_LEDs_buffer[3] = {LED_addr, CYAN, CYAN};
uint8_t WHITE_LEDs_buffer[3] = {LED_addr, WHITE, WHITE};
uint8_t CULE_LEDs_buffer[3] = {LED_addr, BLUE, RED};
uint8_t MERENGUE_LEDs_buffer[3] = {LED_addr, WHITE, WHITE};
uint8_t PERICO_LEDs_buffer[3] = {LED_addr, WHITE, BLUE};
uint8_t GIRONI_LEDs_buffer[3] = {LED_addr, RED, WHITE};
/************************************************************************************/


/*********************** Funcions de control dels LEDs ******************************/
/* Funcions per a l'activació dels LEDs RGB del robot. Les funcions envien una coman-
 * da I2C per encendre els LEDs desitjats amb el color especificat.
 *
 * Cal destacar que en aquesta llibreria es recullen unicament funcions que encenen
 * ambdos LEDs RGB del robot del mateix color. En cas de desitjar una altra combinacio
 * de colors, s'han de definir la trama i la funcio corresponents, les quals permeten
 * aquest comportament. Alternativament, es pot fer l'enviament d'instruccions al cos
 * del programa main.c directament.
 */
void reset_LEDs(void){  // Funció per a apagar els LEDs
    delay_ms(1);
    I2C_send(LOC_ID_ROBOT, LEDs_OFF_buffer, LED_BLEN);
}

void red_LEDs(void){    // Funció per a encendre els LEDs de color vermell
    delay_ms(1);
    I2C_send(LOC_ID_ROBOT, RED_LEDs_buffer, LED_BLEN);
}

void green_LEDs(void){  // Funció per a encendre els LEDs de color verd
    delay_ms(1);
    I2C_send(LOC_ID_ROBOT, GREEN_LEDs_buffer, LED_BLEN);
}

void yellow_LEDs(void){ // Funció per a encendre els LEDs de color groc
    delay_ms(1);
    I2C_send(LOC_ID_ROBOT, YELLOW_LEDs_buffer, LED_BLEN);
}

void blue_LEDs(void){   // Funció per a encendre els LEDs de color blau
    delay_ms(1);
    I2C_send(LOC_ID_ROBOT, BLUE_LEDs_buffer, LED_BLEN);
}

void magenta_LEDs(void){ // Funció per a encendre els LEDs de color magenta
    delay_ms(1);
    I2C_send(LOC_ID_ROBOT, MAGENTA_LEDs_buffer, LED_BLEN);
}

void cyan_LEDs(void){   // Funció per a encendre els LEDs de color cyan
    delay_ms(1);
    I2C_send(LOC_ID_ROBOT, CYAN_LEDs_buffer, LED_BLEN);
}

void white_LEDs(void){  // Funció per a encendre els LEDs de color blanc
    delay_ms(1);
    I2C_send(LOC_ID_ROBOT, WHITE_LEDs_buffer, LED_BLEN);
}

void cule_LEDs(void){  // Funció per a encendre els LEDs de color blaugrana
    delay_ms(1);
    I2C_send(LOC_ID_ROBOT, CULE_LEDs_buffer, LED_BLEN);
}

void merengue_LEDs(void){  // Funció per a encendre els LEDs de color merengue
    delay_ms(1);
    I2C_send(LOC_ID_ROBOT, MERENGUE_LEDs_buffer, LED_BLEN);
}

void perico_LEDs(void){  // Funció per a encendre els LEDs de color blanc
    delay_ms(1);
    I2C_send(LOC_ID_ROBOT, PERICO_LEDs_buffer, LED_BLEN);
}

void gironi_LEDs(void){  // Funció per a encendre els LEDs de color gironi
    delay_ms(1);
    I2C_send(LOC_ID_ROBOT, GIRONI_LEDs_buffer, LED_BLEN);
}
/************************************************************************************/

