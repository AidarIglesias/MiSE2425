/*
 * i2c_master.h
 *
 * Microcontroladors i Sistemes Empotrats
 * Curs 2024-25
 * Universitat de Barcelona
 *
 * Autors: David Garcia, Aidar Iglesias
 * Credits: Professorat de l'assignatura
 */

#ifndef I2C_MASTER_H_
#define I2C_MASTER_H_

void i2c_init();
void I2C_send(uint8_t addr, uint8_t *buffer, uint8_t n_dades);
void I2C_receive(uint8_t addr, uint8_t *buffer, uint8_t n_dades);

#endif /* I2C_MASTER_H_ */
