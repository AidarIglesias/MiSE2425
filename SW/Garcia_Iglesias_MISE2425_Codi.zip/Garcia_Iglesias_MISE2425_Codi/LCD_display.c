/*
 * LCD_display.c
 *
 * Microcontroladors i Sistemes Empotrats
 * Curs 2024-25
 * Universitat de Barcelona
 *
 * Autors: David Garcia, Aidar Iglesias
 */


/********************************* LLIBRERIES ***************************************/
#include <msp430fr2355.h>
#include <stdint.h>
#include <stdio.h>
#include "i2c_master.h"
#include "delay_ms.h"
/************************************************************************************/


/**************************** Variables de control **********************************/
#define LOC_ID_ROBOT 0x10  // Variable local de l'identificador del robot
#define WAIT_10MS 10       // Variable de delay d'inicialització (10ms)
#define LOC_LCD_ADDR 0x3E  // Variable local adreça del LCD
uint8_t LCD_init_buf[8] = {0x00, 0x39, 0x14, 0x74, 0x54, 0x6F, 0x0C, 0x01};  // Búffer d'inicialització del LCD
const uint8_t LCD_init_blen = sizeof(LCD_init_buf);     // Longitud del búffer d'inicialització
uint8_t LCD_clear_buf[2] = {0x00, 0x01};                // Búffer per a esborrar el contingut en pantalla
const uint8_t LCD_clear_blen = sizeof(LCD_clear_buf);   // Longitud del búffer d'esborrar contingut en pantalla
uint8_t LCD_cursor_reset_buf[2] = {0x00, 0x03};         // Búffer per a posicionar el cursor a l'inici de línia
const uint8_t LCD_cursor_reset_blen = sizeof(LCD_cursor_reset_buf); // Longitud del búffer per a posicionar el cursor a l'inici de línia
/************************************************************************************/


/******************* Funció d'inicialització del display LCD ************************/
/* La funcio 'init_LCD' s'encarrega d'inicialitzar els parametres del display LCD
 * d'acord amb les seves caracteristiques fisiques (2x16 caracters) i electriques
 * (3.3V d'alimentacio).
 *
 * En concret, s'habilita el senyal de reset de la pantalla LCD (GPIO del microcon-
 * trolador) durant un cert temps especificat pel fabricant i despres de deshabili-
 * tar-lo, s'envia una seqüencia de caracters per I2C que el configuren.
 */
void init_LCD(void){
    P5DIR |= BIT2;          // Configurem el pin GPIO del reset del LCD com a sortida (actiu per nivell baix
    P5OUT &= ~(BIT2);       // Posem el pin de reset a nivell lògic baix (habilitem reset)
    delay_ms(WAIT_10MS);    // Esperem un temps de configuració (requeriment del fabricant)
    P5OUT |= BIT2;          // Posem el pin de reset a nivell lògic alt (deshabilitem reset)
    delay_ms(WAIT_10MS);    // Esperem un temps de configuració (requeriment del fabricant)
    I2C_send(LOC_LCD_ADDR, LCD_init_buf, LCD_init_blen);  // Enviem la trama d'inicialització per I2C
    delay_ms(WAIT_10MS);    // Esperem un temps de configuració (requeriment del fabricant)
}
/************************************************************************************/


/************************* Funció de reset del display LCD **************************/
/* La funcio 'LCD_reset' envia un senyal de reset al display LCD. La utilitat de la
 * funcio es desfer-se de la tasca de treballar a nivell de GPIOs. Amb nomes cridar
 * la funcio ja es fa el reset.
 */
void LCD_reset(void){
    P5OUT &= ~(BIT2);       // Habilitem reset
    delay_ms(WAIT_10MS);    // Esperem 10ms
    P5OUT |= BIT2;          // Deshabilitem reset
    delay_ms(WAIT_10MS);    // Esperem 10ms
}
/************************************************************************************/


/****************** Funció per esborrar el contingut del display LCD ****************/
/* La funcio 'LCD_clear' te com a finalitat esborrar el contingut presentat a la pan-
 * talla. La posicio del cursor tambe retorna al primer caracter de la primera linia.
 */
void LCD_clear(void){
    delay_ms(WAIT_10MS);  // Esperem 10ms
    I2C_send(LOC_LCD_ADDR, LCD_clear_buf, LCD_clear_blen);  // Enviem comanda d'esborrament en
        // pantalla per I2C
}
/************************************************************************************/


/********** Funció per posar el cursor del display LCD a la posició inicial**********/
/* La funcio 'LCD_cursor_reset' s'empra per, en el moment que es desitgi, retornar el
 * cursor a la posicio inicial, es a dir, al primer caracter de la primera linia.
 */
void LCD_cursor_reset(void){
    delay_ms(WAIT_10MS);  // Esperem 10ms
    I2C_send(LOC_LCD_ADDR, LCD_cursor_reset_buf, LCD_cursor_reset_blen);  // Enviem comanda de
        // posicionament del cursor a l'inici de la primera línia del display
}
/************************************************************************************/


/********** Funcio sprintf per posar missatge "INFORME SOFTWARE MISE" ***************/
/* La funcio 'LCD_send' envia la cadena "INFORME SOFTWARE MISE" a la pantalla LCD.
 * Per fer-ho, es construeixen les diferents cadenes corresponents a cada paraula
 * de la frase i s'envien via I2C al display.
 */
void LCD_send(void){
    uint8_t cadena[10]; // Declarem un array per desar la cadena de caracters
    uint8_t llarg;      // Declarem la mida de la cadena de caracters

    /* Construim la cadena de caracters mitjançant la funcio 'sprintf' de la
     * llibreria <stdio.h> de C
     */
    llarg = sprintf(cadena,"@INFORME ",llarg);
    I2C_send(LOC_LCD_ADDR, cadena, llarg);      // Enviem la cadena per I2C al LCD

    // Repetim el mateix per a la següent paraula
    llarg = sprintf(cadena,"@SOFTWARE ",llarg);
    I2C_send(LOC_LCD_ADDR, cadena, llarg);      // Enviem la cadena per I2C al LCD

    /* Enviem una cadena de caracters que corresponen a un salt de linia
     * (vegeu app. note del fabricant per a les trames de control)
     */
    uint8_t cursor_segona_linea[2] = {0x00, 0xC0};
    I2C_send(LOC_LCD_ADDR, cursor_segona_linea, 2); // Enviem la cadena per I2C al LCD
    delay_ms(WAIT_10MS);                            // Esperem 10ms

    // Construim la cadena per a la ultima paraula de la frase
    llarg = sprintf(cadena, "@MISE");
    I2C_send(LOC_LCD_ADDR, (uint8_t*)cadena, llarg); // Enviem la cadena per I2C al LCD
}
/************************************************************************************/

