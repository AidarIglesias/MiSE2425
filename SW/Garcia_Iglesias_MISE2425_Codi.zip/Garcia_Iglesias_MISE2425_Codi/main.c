/*
 * main.c
 *
 * Microcontroladors i Sistemes Empotrats
 * Curs 2024-25
 * Universitat de Barcelona
 *
 * Autors: David Garcia, Aidar Iglesias
 */


/********************************* LLIBRERIES ***********************************/
// Llibreries estandard de C i del microcontrolador
#include <msp430fr2355.h>
#include <stdint.h>
#include <stdio.h>
// Fitxers de capçalera
#include "timers.h"
#include "delay_ms.h"
#include "i2c_master.h"
#include "LEDs.h"
#include "LCD_display.h"
#include "actuadors.h"
#include "linetracking.h"
/********************************************************************************/


/***************************** Variables globals ********************************/
/* En aquest apartat es defineixen tant les variables globals com les macros emprades
 * en els diferents moduls del programa
 */
// Variables delay
#define WAIT_1MS 1              // Espera d'un mil·lisegon
#define WAIT_100MS 100          // Espera de cent mil·lisegons
#define WAIT_HALF_SEC 500       // Espera de mig segon
#define WAIT_1S 1000            // Espera d'un segon
#define WAIT_2S 2000            // Espera de dos segons

// ID del robot com a esclau
#define GLOB_ID_ROBOT 0x10      // Identificador del robot

// LCD display robot
#define GLOB_LCD_ADDR 0x3E      // Adreça del display LCD
#define LCD_TX_DELAY 10         // Espera entre missatges enviats al LCD

// Actuadors
#define GLOB_ACTUATOR_ADDR 0x00 // Adreça global del controlador d'actuadors
#define VEL 40                  // Velocitat inicial dels actuadors

// Line-Track
#define LINETRACK_VEL 40        // Velocitat del robot en mode line-track
/* Creem un bloc condicional a nivell de compilador per escollir el mode de funcionament
 * del modul line-track amb les macros #ifndef, #define i #endif
 */
#define LINE_TRACK_MODE 0       // Mode de funcionament: seguiment de linia centrada
#ifndef LINE_TRACK_MODE
#define WALL_FOLLOWER_MODE 1    // Mode de funcionament: seguiment de paret
#endif
/********************************************************************************/


/************************ Funcio inicialitzacio de rellotges ********************/
void init_clock(void)
{
    FRCTL0 = FRCTLPW | NWAITS_1;

    P2SEL1 |= BIT6 | BIT7;              // P2.6~P2.7: crystal pins
    do
    {
        CSCTL7 &= ~(XT1OFFG | DCOFFG);  // Clear XT1 and DCO fault flag
        SFRIFG1 &= ~OFIFG;
    }while (SFRIFG1 & OFIFG);           // Test oscillator fault flag

    __bis_SR_register(SCG0);            // disable FLL
    CSCTL3 |= SELREF__XT1CLK;           // Set XT1 as FLL reference source
    //CSCTL1 = DCOFTRIMEN_1 | DCOFTRIM0 | DCOFTRIM1 | DCORSEL_5; // DCOFTRIM=5, DCO Range = 16MHz**
    CSCTL1 = DCORSEL_5;                 // DCOFTRIM=5, DCO Range = 16MHz
    CSCTL2 = FLLD_0 + 487;              // DCOCLKDIV = 16MHz
    __delay_cycles(3);
    __bic_SR_register(SCG0);            // enable FLL
    //Software_Trim();                  // Software Trim to get the best DCOFTRIM value**

    CSCTL4 = SELMS__DCOCLKDIV | SELA__XT1CLK;   // set XT1 (~32768Hz) as ACLK source, ACLK = 32768Hz
                                                // default DCOCLKDIV as MCLK and SMCLK source

    // P1DIR |= BIT0 | BIT1;            // set SMCLK, ACLK pin as output
    // P1SEL1 |= BIT0 | BIT1;           // set SMCLK and ACLK pin as second function
    PM5CTL0 &= ~LOCKLPM5;               // Disable the GPIO power-on default high-impedance mode
                                        // to activate previously configured port settings
}
/********************************************************************************/


/*********** Funcio inicialitzacio LED P1.0 de la placa Launchpad ***************/
void init_LED_MSP(){
    P1DIR |= BIT0;      // LED P1.0 com a sortida
    P1SEL0 &= ~(BIT0);  // Funcio principal del
    P1SEL1 &= ~(BIT0);  // pin com a GPIO
}
/********************************************************************************/


/*********** Funcio inicialitzacio pin P2.0 de la placa Launchpad ***************/
void init_Port2IO(void){
    P2DIR |= BIT0;      // P2.0 com a sortida
    P2SEL0 &= ~(BIT0);  // Funcio principal del
    P2SEL1 &= ~(BIT0);  // pin com a GPIO
}
/********************************************************************************/


/************************* BEGIN MAIN PROGRAM ***********************************/
void main(void)
{
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer

    /******************** Habilitar interrupcions globals ***********************/
    __enable_interrupt();
    /****************************************************************************/

	/************************ Inicialitzacio de funcions ************************/
	// Inicialitzacio de rellotges
	init_clock();
	// Inicialitzacio de l'I2C
	i2c_init();
	// Inicialitzacio del LED P1.0 de la placa (nomes al Launchpad)
	init_LED_MSP();
	// Inicialitzacio del pin P2.0 de la placa (nomes al Launchpad)
	init_Port2IO();
	// Inicialitzacio del TimerB3
	init_TimerB3();
	// Inicialitzacio del display LCD
	init_LCD();
	/****************************************************************************/


	/****************** Comprovacio de la funcio delay_ms()**********************/
	// Comprovar la funcio delay_ms()
	P1OUT |= BIT0;      // Encenem el LED vermell P1.0
	P2OUT |= BIT0;      // Posem a nivell logic alt el pin 2.0
	delay_ms(WAIT_1S);  // Esperem un segon
	P1OUT &= ~(BIT0);   // Apaguem el LED vermell P1.0
	P2OUT &= ~(BIT0);   // Posem a nivell logic baix el pin 2.0
	/****************************************************************************/


	/********************* Control de LEDs RGB del robot ************************/
	// Escriptura als LEDs RGB frontals del robot
	red_LEDs();                 // Encendre els LEDs de color vermell
	delay_ms(WAIT_HALF_SEC);    // Esperar mig segon
	green_LEDs();               // Encendre els LEDs de color verd
	delay_ms(WAIT_HALF_SEC);    // Esperar mig segon
	yellow_LEDs();              // Encendre els LEDs de color groc
	delay_ms(WAIT_HALF_SEC);    // Esperar mig segon
	blue_LEDs();                // Encendre els LEDs de color blau
	delay_ms(WAIT_HALF_SEC);    // Esperar mig segon
	magenta_LEDs();             // Encendre els LEDs de color magenta
	delay_ms(WAIT_HALF_SEC);    // Esperar mig segon
	cyan_LEDs();                // Encendre els LEDs de color cyan
	delay_ms(WAIT_HALF_SEC);    // Esperar mig segon
	white_LEDs();               // Encendre els LEDs de color blanc
	delay_ms(WAIT_HALF_SEC);    // Esperar mig segon
	cule_LEDs();                // Encendre els LEDs de color FC Blaugrana
	delay_ms(WAIT_HALF_SEC);    // Esperar mig segon
	merengue_LEDs();            // Encendre els LEDs de color Real Madrid CF
	delay_ms(WAIT_HALF_SEC);    // Esperar mig segon
	perico_LEDs();              // Encendre els LEDs de color RCD Espanyol
	delay_ms(WAIT_HALF_SEC);    // Esperar mig segon
	gironi_LEDs();              // Encendre els LEDs de color Girona FC
	delay_ms(WAIT_HALF_SEC);    // Esperar mig segon
	reset_LEDs();               // Apagar els LEDs
	delay_ms(WAIT_HALF_SEC);    // Esperar mig segon
	/****************************************************************************/


	/*********************** Comunicacio amb LCD display ************************/
	uint8_t msg[12];                        // Array on es desa el missatge a transmetre
    /* Desem cadascun dels caracters del contingut del missatge en una variable de
     * tipus array mitjançant la funció de C sprintf() i desem la mida d'aquest */
	uint8_t msg_len = sprintf(msg, "@Hello World");
	delay_ms(LCD_TX_DELAY); // Esperem 10ms
	I2C_send(GLOB_LCD_ADDR, msg, msg_len);   // Enviem el missatge per I2C al LCD
	delay_ms(WAIT_2S);      // Esperem 2s
	LCD_clear();            // Esborrem el contingut en pantalla
	delay_ms(LCD_TX_DELAY); // Esperem 10ms
	LCD_send();             // Enviem el missatge "INFORME SOFTWARE MISE" al LCD
	/****************************************************************************/


	/************************* Control dels actuadors ***************************/
	move_forward(VEL);  // Habilitar els actuadors per avançar
	delay_ms(WAIT_1S);  // Esperar un segon
	fleft(VEL);         // Habilitar els actuadors per girar cap a l'esquerra endavant
	delay_ms(WAIT_1S);  // Esperar un segon
	fright(VEL);        // Habilitar els actuadors per girar cap a la dreta endavant
	delay_ms(WAIT_1S);  // Esperar un segon
	stop();             // Deshabilitar els actuadors per aturar el robot
	delay_ms(WAIT_1S);  // Esperar un segon
	move_backward(VEL); // Habilitar els actuadors per retrocedir
	delay_ms(WAIT_1S);  // Esperar un segon
	bleft(VEL);         // Habilitar els actuadors per girar cap a l'esquerra enrere
	delay_ms(WAIT_1S);  // Esperar un segon
	bright(VEL);        // Habilitar els actuadors per girar cap a la dreta enrere
	delay_ms(WAIT_1S);  // Esperar un segon
	stop();             // Deshabilitar els actuadors per aturar el robot
	delay_ms(WAIT_1S);  // Esperar un segon
	left_rot(VEL);      // Habilitar els actuadors per rotar en sentit antihorari
	delay_ms(WAIT_1S);  // Esperar un segon
	right_rot(VEL);     // Habilitar els actuadors per rotar en sentit horari
	delay_ms(WAIT_1S);  // Esperar un segon
	stop();             // Deshabilitar els actuadors per aturar el robot
	/****************************************************************************/


	while(1){   // Bucle infinit per al main
	    // Codi per a la comprovacio del delay a traves de l'oscil·loscopi
	    P2OUT |= BIT0;      // Posem a nivell logic alt el pin 2.0
	    delay_ms(WAIT_100MS);  // Esperem un segon
	    P2OUT &= ~(BIT0);   // Posem a nivell logic baix el pin 2.0
	    delay_ms(WAIT_100MS);  // Esperem un segon

	    // Codi del Line-Track
	    delay_ms(50);
	    /* En funcio de quin mode de funcionament del modul de line-track s'ha escollit
	     * al principi, s'executa la funcio amb el mode corresponent
	     */
#ifdef LINE_TRACK_MODE
	    linetrack(LINE_TRACK_MODE, LINETRACK_VEL);
#else
	    linetrack(WALL_FOLLOWER_MODE, LINETRACK_VEL);
#endif
	}
}
/********************************************************************************/

