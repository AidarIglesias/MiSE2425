/*
 * linetracking.c
 *
 * Microcontroladors i Sistemes Empotrats
 * Curs 2024-25
 * Universitat de Barcelona
 *
 * Autors: David Garcia, Aidar Iglesias
 */


/********************************* LLIBRERIES ***************************************/
#include <msp430fr2355.h>
#include <stdint.h>
#include "timers.h"
#include "LCD_display.h"
#include "actuadors.h"
#include "delay_ms.h"
#include "i2c_master.h"
/************************************************************************************/


/******************************* VARIABLES DE CONTROL *******************************/
#define LOC_ID_ROBOT 0x10       // Adreça I2C del robot
#define LINE_TRACK_ADDR 0x1D    // Adreça del controlador del modul de seguiment de linia
#define WAIT_10MS 10            // Delay de 10ms entre la transmisio i la rececpcio del line-track
uint8_t linetrack_reg[6];       // Variable que emmagatzema els bits d'estat de cadascun dels fotodetectors
/************************************************************************************/


/****************** Funcio d'execucio del mode de seguiment de linia ****************/
/* La funcio de seguiment de linia 'linetrack' accepta dos arguments. El primer es
 * el mode de funcionament, el format del qual ve donat per un nombre enter de 8 bits.
 * El segon argument es la velocitat del robot durant l'etapa de seguiment de linia.
 * No retorna cap dada (tipus void).
 *
 * La funcio esta dividida en dos fases: la fase de mesura i la de presa de decisio.
 * Durant la fase de presa de mesura s'envia la comanda de mesura via I2C al contro-
 * lador dels fotodetectors. Un cop feta la mesura, les dades d'aquesta es processen
 * i es preparen per a la següent fase. Durant la fase de presa de decisio s'envien
 * comandes d'operacio als actuadors del robot en funcio del valor dels fotodetectors.
 *
 * La funcio te dos modes principals de funcionament: seguiment de linia i seguiment de
 * paret. En el mode de seguiment de linia, el robot tractara de seguir la linia amb
 * la roda passiva davantera, si mes no mantenir la linia entre les dues rodes actives.
 * En el mode de seguiment de paret, el robot avançara fins que es trobi una paret, cas
 * en el qual rotara cap a la dreta fins que detecti que no col·lisiona, aleshores
 * avançara mantenint'se al marge d'aquesta.
 *
 * Els punts febles del robot son els camins sense sortida (tots els fotodetectors
 * detecten una col·lisio imminent) i que en el mode de seguiment de paret, el robot
 * evita la col·lisio, pero no mante una distancia constant amb la paret.
 */
void linetrack(uint8_t mode, uint8_t linetrack_vel) {

    /********************** Fase de mesura dels fotodetectors ***********************/
    // Inicialitzar els buffers de transmisio i recepcio
    uint8_t tx_buf[1] = {LINE_TRACK_ADDR};  // Byte a enviar per activar el sensor
    uint8_t rx_buf[1] = {0x00};             // Byte de recepció inicialitzat a 0
    uint8_t tx_buf_len = sizeof(tx_buf);    // Longitud del buffer de transmissio
    uint8_t rx_buf_len = sizeof(rx_buf);    // Longitud del buffer de recepcio

    // Enviar la peticio de mesura al registre del modul line-track
    I2C_send(LOC_ID_ROBOT, tx_buf, tx_buf_len);
    delay_ms(WAIT_10MS);

    // Rebre i desar la resposta
    I2C_receive(LOC_ID_ROBOT, rx_buf, rx_buf_len);
    linetrack_reg[0] = rx_buf[0] & ((uint8_t)BIT0);        // Extraiem i desem els bits del registre
    linetrack_reg[1] = (rx_buf[0] & ((uint8_t)BIT1)) >> 1; // dels fotodetectors mitjançant una mascara
    linetrack_reg[2] = (rx_buf[0] & ((uint8_t)BIT2)) >> 2; // de bit i desplaçaments
    linetrack_reg[3] = (rx_buf[0] & ((uint8_t)BIT3)) >> 3;
    linetrack_reg[4] = (rx_buf[0] & ((uint8_t)BIT4)) >> 4;
    linetrack_reg[5] = (rx_buf[0] & ((uint8_t)BIT5)) >> 5;
    /********************************************************************************/


    /************************** Fase de presa de decisio ****************************/
    switch(mode){

    case 0: // Mode de funcionament: seguiment de linia (LINE_TRACK_MODE)
        if(linetrack_reg[0]){
            /* excrusio excessiva cap a la dreta --> rotar en sentit antihorari */
            delay_ms(5);
            left_rot(linetrack_vel);
            delay_ms(5);
        } else if(linetrack_reg[5]){
            /* excursio excessiva cap a l'esquerra --> rotar en sentit horari */
            delay_ms(5);
            right_rot(linetrack_vel);
            delay_ms(5);
        } else if(linetrack_reg[1] | linetrack_reg[2]){
            /* s'ha detectat limit esquerre de la linia --> girar cap a l'esquerra */
            delay_ms(5);
            fleft(linetrack_vel);
            delay_ms(5);
        } else if(linetrack_reg[3] | linetrack_reg[4]){
            /* s'ha detectat limit dret de la linia --> girar cap a la dreta */
            delay_ms(5);
            bright(linetrack_vel);
            delay_ms(5);
        } else{
            /* ens trobem dintre dels limits --> avançar */
            delay_ms(5);
            move_forward(linetrack_vel);
            delay_ms(5);
        }
        break;

    case 1: // Mode de funcionament seguiment de paret (WALL_FOLLOWER_MODE)
        if(linetrack_reg[5] & linetrack_reg[4] & linetrack_reg[3] & linetrack_reg[2] & linetrack_reg[1] & linetrack_reg[0]){
            /* s'ha arribat a un cami sense sortida --> aturem el robot*/
            delay_ms(5);
            stop();
            delay_ms(5);
        } else if(linetrack_reg[4] & linetrack_reg[3] & linetrack_reg[2] & linetrack_reg[1]){
            /* s'ha arribat a una paret frontal --> aturem el robot*/
            delay_ms(5);
            stop();
            delay_ms(5);
            right_rot(linetrack_vel);
            delay_ms(500);
            stop();
            delay_ms(5);
        } else if(linetrack_reg[1] & linetrack_reg[0]){
            /* s'ha detectat una cantonada esquerra --> rota en sentit horari*/
            delay_ms(5);
            right_rot(linetrack_vel);
            delay_ms(5);
        } else if(linetrack_reg[5] & linetrack_reg[4]){
            /* s'ha detectat una cantonada dreta --> rota en sentit antihorari*/
            delay_ms(5);
            left_rot(linetrack_vel);
            delay_ms(5);
        } else if(linetrack_reg[0]){
            /* s'ha detectat una paret lateral a l'esquerra --> gira cap a la dreta */
            delay_ms(5);
            fright(linetrack_vel);
            delay_ms(5);
        } else if(linetrack_reg[5]){
            /* s'ha detectat una paret lateral a la dreta --> gira cap a l'esquerra */
            delay_ms(5);
            fleft(linetrack_vel);
            delay_ms(5);
        } else{
            /* en qualsevol altre cas --> avança */
            delay_ms(5);
            move_forward(0.8*linetrack_vel);
            delay_ms(5);
        }
        break;
    }
    /********************************************************************************/
}
/************************************************************************************/
