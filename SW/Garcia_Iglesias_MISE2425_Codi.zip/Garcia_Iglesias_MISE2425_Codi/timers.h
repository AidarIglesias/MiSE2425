/*
 * timers.h
 *
 * Microcontroladors i Sistemes Empotrats
 * Curs 2024-25
 * Universitat de Barcelona
 *
 * Autors: David Garcia, Aidar Iglesias
 */

#ifndef TIMERS_H_
#define TIMERS_H_

void init_TimerB3(void);

#endif /* TIMERS_H_ */
