/*
 * LEDs.h
 *
 * Microcontroladors i Sistemes Empotrats
 * Curs 2024-25
 * Universitat de Barcelona
 *
 * Autors: David Garcia, Aidar Iglesias
 */

#ifndef LEDS_H_
#define LEDS_H_

void reset_LEDs(void);
void red_LEDs(void);
void green_LEDs(void);
void yellow_LEDs(void);
void blue_LEDs(void);
void magenta_LEDs(void);
void cyan_LEDs(void);
void white_LEDs(void);
void cule_LEDs(void);
void merengue_LEDs(void);
void perico_LEDs(void);
void gironi_LEDs(void);

#endif /* LEDS_H_ */
