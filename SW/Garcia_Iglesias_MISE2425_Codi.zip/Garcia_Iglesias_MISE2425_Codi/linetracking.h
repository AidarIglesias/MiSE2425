/*
 * linetracking.h
 *
 *  Created on: Apr 22, 2025
 *      Author: aidar
 */

#ifndef LINETRACKING_H_
#define LINETRACKING_H_

void linetrack(uint8_t mode, uint8_t linetrack_vel);

#endif /* LINETRACKING_H_ */

