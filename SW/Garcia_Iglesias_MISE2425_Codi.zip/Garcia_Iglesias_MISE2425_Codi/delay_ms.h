/*
 * delay_ms.h
 *
 * Microcontroladors i Sistemes Empotrats
 * Curs 2024-25
 * Universitat de Barcelona
 *
 * Autors: David Garcia, Aidar Iglesias
 */

#ifndef DELAY_MS_H_
#define DELAY_MS_H_

void init_TimerB(void);
void delay_ms(uint16_t ms);

#endif /* DELAY_MS_H_ */
