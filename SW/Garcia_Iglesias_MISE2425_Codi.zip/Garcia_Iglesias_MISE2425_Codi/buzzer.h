/*
 * delay_ms.h
 *
 * Microcontroladors i Sistemes Empotrats
 * Curs 2024-25
 * Universitat de Barcelona
 *
 * Autors: David Garcia, Aidar Iglesias
 */

#ifndef BUZZER_H_
#define BUZZER_H_

void buzzer_PWM(unsigned int frecuencia, unsigned int duty_percent);


#endif /* DELAY_MS_H_ */

