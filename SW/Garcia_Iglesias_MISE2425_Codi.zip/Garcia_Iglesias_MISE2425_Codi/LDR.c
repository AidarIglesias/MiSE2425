/*
 * LDR.c
 *
 * Microcontroladors i Sistemes Empotrats
 * Curs 2024-25
 * Universitat de Barcelona
 *
 * Autors: David Garcia, Aidar Iglesias
 */

/***************************** MACROS I LLIBRERIES **********************************/
#include <msp430fr2355.h>
#include <stdint.h>
#include "timers.h"
#include "LCD_display.h"
/************************************************************************************/


/************** Funcions per al control i presa de mesures amb l'ADC ****************/
// Funció per a la inicialització dels pins de l'ADC (A8 i A9)
void init_LDRpins(void){
    PM5CTL0 &= ~LOCKLPM5;               // Disable the GPIO power-on default high-impedance mode
                                        // to activate previously configured port settings
    P5DIR &= ~(BIT0 | BIT1);            // Select A/D channel inputs
    P5SEL0 |= (BIT0 | BIT1);            // Enable A/D channel inputs
    P5SEL1 &= ~(BIT0 | BIT1);           // Enable A/D channel inputs
    ADCCTL0 |= (ADCON | ADCSHT_2);      // Turn on ADC12, S&H=16 clks
    ADCCTL1 |= (ADCSSEL_0 |  ADCSHP);    // ADCLK=MODOSC & sampling Timer as source for sampling
    ADCCTL2 &= ~ADCRES;                 // Clear previous ADCRES config in ADCTL
    ADCCTL2 |= ADCRES_2;                // Set ADCRES to 12 bits of resolution
    ADCMCTL0 |= ADCSREF_0;              // Select AVCC and AVSS as pos. and neg. references
    ADCIE |= ADCIE0;                    // Enable interrupt RQ for completed conversion
}

// Funció per a la presa d'una mesura del canal A8
void chan_A8(void){
    ADCCTL0 |= ADCENC | ADCSC;          // Començar el mostreig i conversió

}

// Funció per a la presa d'una mesura del canal A9
void chan_A9(void){

}
/************************************************************************************/


/************************** Inicialització ISR de l'ADC12 ***************************/
#pragma vector=ADC_VECTOR
__interrupt void ADC_ISR(void){
    switch(__even_in_range(ADCIV,ADCIV_ADCIFG)){
        case ADCIV_NONE:
            break;
        case ADCIV_ADCOVIFG:
            break;
        case ADCIV_ADCTOVIFG:
            break;
        case ADCIV_ADCHIIFG:
            break;
        case ADCIV_ADCLOIFG:
            break;
        case ADCIV_ADCINIFG:
            break;
        case ADCIV_ADCIFG:
            //ADC_Result = ADCMEM0;
            __bic_SR_register_on_exit(LPM0_bits);            // Clear CPUOFF bit from LPM0
            break;
        default:
            break;
    }
}
/************************************************************************************/

