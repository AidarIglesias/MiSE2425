/*
 * delay_ms.c
 *
 * Microcontroladors i Sistemes Empotrats
 * Curs 2024-25
 * Universitat de Barcelona
 *
 * Autors: David Garcia, Aidar Iglesias
 */


/******************************* LLIBRERIES *************************************/
#include <msp430fr2355.h>
#include <stdint.h>
#include "timers.h"
/********************************************************************************/


/************************** Variables de control ********************************/
uint16_t count_ms = 0;
/********************************************************************************/


/**************************** Funció delay_ms ***********************************/
/* La funcio delay_ms accepta un unic argument de tipus enter de 8 bits i no retorna
 * cap dada (tipus void). L'argument que se li passa a la funcio es la quantitat de
 * temps d'espera (en mil·lisegons) que es desitja fer.
 *
 * La funcio explota el Timer B3 com a temporitzador per al recompte del pas del temps.
 * A l'inici es fa la inicialitzacio del temporitzador: s'esborra el valor emmagat-
 * zemat al registre de recompte, s'habiliten les interrupcions de comptador i s'ha-
 * bilita el temporitzador. Un cop acabat el recompte, es deshabilita el temporitzador.
 *
 * El recompte es controla mitjançant una variable de recompte que s'incrementa mitjan-
 * çant una interrupcio, la qual es genera cada cop que el temporitzador finalitza el
 * periode d'un mil·lisegon.
 */
void delay_ms(uint16_t ms){  // Funció d'espera de milisegons
    count_ms = 0;                       // Inicialitzem la variable count_ms a 0
    TB3CTL |= TBCLR;                    // Esborrem el valor de recompte
    TB3CCTL0 |= CCIE;                   // Habilitem les interrupcions del comptador del TimerB3
    TB3CTL |= MC__UP;                   // Comencem el recompte
    while(count_ms < ms){
        // cos del bucle buit (comptant...)
    }
    TB3CTL &= ~(MC__UP);                // Deshabilitem el TimerB3
}
/********************************************************************************/


/*********************** Inicialització ISR del TimerB3 *************************/
#pragma vector = TIMER3_B0_VECTOR
__interrupt void TimerB0_ISR (void){
    count_ms += 1; // Incrementem la variable de recompte en 1 i deshabilitem les interrupcions.
}
/********************************************************************************/
