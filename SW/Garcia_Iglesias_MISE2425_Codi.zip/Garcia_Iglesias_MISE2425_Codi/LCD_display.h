/*
 * LCD_display.h
 *
 * Microcontroladors i Sistemes Empotrats
 * Curs 2024-25
 * Universitat de Barcelona
 *
 * Autors: David Garcia, Aidar Iglesias
 */

#ifndef LCD_DISPLAY_H_
#define LCD_DISPLAY_H_

void init_LCD(void);
void LCD_reset(void);
void LCD_clear(void);
void LCD_cursor_reset(void);
void LCD_send(void);

#endif /* LCD_DISPLAY_H_ */
