/*
 * LDR.h
 *
 * Microcontroladors i Sistemes Empotrats
 * Curs 2024-25
 * Universitat de Barcelona
 *
 * Autors: David Garcia, Aidar Iglesias
 */

#ifndef LDR_H_
#define LDR_H_

void init_LDRpins(void);
void chan_A8(void);
void chan_A9(void);

#endif /* LDR_H_ */
