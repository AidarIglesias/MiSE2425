/*
 * timers.c
 *
 * Microcontroladors i Sistemes Empotrats
 * Curs 2024-25
 * Universitat de Barcelona
 *
 * Autors: David Garcia, Aidar Iglesias
 */


/********************************* LLIBRERIES ***************************************/
#include <msp430fr2355.h>
#include <stdint.h>
/************************************************************************************/


/************************* Funció iniciatització TimerB3 ****************************/
/* La funcio 'init_TimerB3' configura el TimerB3 amb un periode d'un mil·lisegon
 * i amb el rellotge SMCLK com a font de recompte.
 */
void init_TimerB3(void){
    TB3CTL |= TBSSEL__SMCLK;            // Configurem el TimerB3 amb el registre de recompte
                                        // a 16 bits, assigem com a rellotge font el rellotge
                                        // SMCLK, deshabilitem les interrupcions i esborrem les
                                        // banderes d'interrupció pendents
    TB3CCR0 = 16000;                    // Ajustem el periode del timer a 1 ms
}
/************************************************************************************/

