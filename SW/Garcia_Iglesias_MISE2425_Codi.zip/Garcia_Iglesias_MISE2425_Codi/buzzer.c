/*
 * Buzzer.c
 *
 * Microcontroladors i Sistemes Empotrats
 * Curs 2024-25
 * Universitat de Barcelona
 *
 * Autors: David Garcia, Aidar Iglesias
 */


/********************************* LLIBRERIES ***************************************/
#include <msp430fr2355.h>
#include <stdint.h>
#include "timers.h"
#include "LCD_display.h"
#include "actuadors.h"
/************************************************************************************/



// Frecuencia en Hz y ciclo �til (duty) en porcentaje (0 - 100)
void initPWMBuzzer(unsigned int frecuencia, unsigned int duty_percent) {
    WDTCTL = WDTPW | WDTHOLD;   // Detener el Watchdog Timer

    // Configurar P1.6 como salida de PWM (usaremos TB0.1 en P1.6)
    P1DIR |= BIT6;
    P1SEL1 &= ~BIT6;
    P1SEL0 |= BIT6;  // Seleccionar funci�n secundaria: TB0.1

    // Calcular el periodo (CCR0) y duty (CCR1) para la frecuencia deseada
    unsigned int periodo = 1000000 / frecuencia; // SMCLK ~1MHz
    unsigned int duty = (periodo * duty_percent) / 100;

    // Configurar Timer_B0
    TB0CCTL1 = OUTMOD_7;          // Reset/Set
    TB0CCR0 = periodo - 1;        // Periodo PWM
    TB0CCR1 = duty;               // Ciclo �til

    TB0CTL = TBSSEL_2 | MC_1 | TBCLR;  // SMCLK, modo up, clear
}


/************************************************************************************/

